{"workerId":"docker-149-023","taskId":"149-023","status":"EXECUTING","sequence":57,"timestamp":"2026-04-20T21:37:11.000Z","backend":"docker"}
